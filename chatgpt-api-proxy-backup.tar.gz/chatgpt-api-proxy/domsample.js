const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  const sel = '#mobile-composer-prompt, #prompt-textarea, textarea';
  await page.waitForSelector(sel, { timeout: 30000 });
  await page.click(sel);
  await page.waitForTimeout(800);
  await page.keyboard.type('Count from 1 to 5, one number per line.', { delay: 15 });
  await page.waitForTimeout(500);
  await page.click('button[aria-label*="Send" i]');
  await page.waitForTimeout(3000);

  // sample the DOM during streaming
  for (let i = 0; i < 12; i++) {
    const snap = await page.evaluate(() => {
      const out = {};
      // look for the assistant turn container
      const turns = [...document.querySelectorAll('[data-web-mobile-conversation-turn-marker]')];
      out.turnMarkers = turns.length;
      const arts = [...document.querySelectorAll('article')];
      out.articles = arts.length;
      if (arts.length) {
        const last = arts[arts.length - 1];
        out.lastArticleText = last.innerText.slice(0, 300);
        out.lastArticleHtml = last.outerHTML.slice(0, 500);
      }
      // any streaming/mark elements
      out.streaming = [...document.querySelectorAll('[class*="stream"], [data-streaming], .result-streaming')].length;
      out.url = location.href;
      return out;
    });
    console.log('--- t+' + (i * 1.5) + 's', JSON.stringify(snap).slice(0, 900));
    await page.waitForTimeout(1500);
  }
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
