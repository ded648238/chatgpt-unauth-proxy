const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  const saved = [];
  page.on('response', async (resp) => {
    const url = resp.url();
    if (/\.(?:js|json)(\?|$)/.test(url) && !saved.includes(url)) {
      saved.push(url);
      try {
        const body = await resp.body();
        if (/conversation|backend-api/.test(body.toString('utf8'))) {
          const name = url.split('/').pop().split('?')[0];
          fs.writeFileSync('/tmp/opencode/js/' + name, body);
          console.log('SAVED', name, body.length);
        }
      } catch {}
    }
  });
  try {
    await page.goto('https://chatgpt.com/c/1', { timeout: 90000, waitUntil: 'domcontentloaded' });
    for (let i = 0; i < 30; i++) {
      const html = await page.content();
      if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
      await page.waitForTimeout(2000);
    }
    await page.waitForTimeout(8000);
    console.log('TITLE:', await page.title());
  } finally {
    await ctx.close();
  }
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
