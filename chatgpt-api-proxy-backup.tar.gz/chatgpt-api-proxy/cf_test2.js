const { chromium } = require('playwright');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  await ctx.addInitScript(() => { Object.defineProperty(navigator, 'webdriver', { get: () => false }); });
  const page = await ctx.newPage();
  const t0 = Date.now();
  try {
    await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
    // wait for challenge to clear (up to ~60s)
    for (let i = 0; i < 30; i++) {
      const html = await page.content();
      if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
      await page.waitForTimeout(2000);
    }
    const html = await page.content();
    console.log('elapsed', ((Date.now() - t0) / 1000).toFixed(1) + 's len=' + html.length);
    console.log('cf_challenge:', html.includes('_cf_chl_opt') || html.includes('Just a moment'));
    console.log('title:', await page.title());
    console.log('cookies:', (await page.context().cookies()).map(c => c.name).join(','));
    const res = await page.evaluate(async () => {
      try {
        const r = await fetch('https://chatgpt.com/backend-api/models', { credentials: 'include' });
        return { status: r.status, body: (await r.text()).slice(0, 300) };
      } catch (e) { return { err: String(e) }; }
    });
    console.log('models:', JSON.stringify(res).slice(0, 400));
  } finally {
    await ctx.close();
  }
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
