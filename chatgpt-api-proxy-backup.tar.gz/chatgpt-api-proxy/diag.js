const { chromium } = require('playwright');
const { ChatGPTDriver } = require('./driver');

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const d = new ChatGPTDriver();
  await d.attach(browser);
  await d.warmup();
  console.log('warm ok, url:', await d.page.evaluate(() => location.href));

  const r1 = await d.ask('Reply with one word: ok', () => {});
  console.log('R1:', JSON.stringify(r1));
  console.log('url after r1:', await d.page.evaluate(() => location.href));

  // diagnose composer state after a turn
  const diag = await d.page.evaluate(() => {
    const el = document.querySelector('#mobile-composer-prompt, #prompt-textarea, textarea');
    const btns = [...document.querySelectorAll('button[aria-label*="Send" i]')];
    return {
      composer: el ? { tag: el.tagName, disabled: el.disabled, value: el.value.slice(0, 40), rect: (() => { const r = el.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })() } : null,
      sendBtns: btns.map(b => ({ disabled: b.disabled, aria: b.getAttribute('aria-label'), rect: (() => { const r = b.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })() })),
      bodyHead: document.body.innerText.slice(0, 400),
    };
  });
  console.log('DIAG:', JSON.stringify(diag, null, 1).slice(0, 2500));
  await d.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
