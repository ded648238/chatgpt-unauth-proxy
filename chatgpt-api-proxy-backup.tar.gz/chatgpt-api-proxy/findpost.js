const { chromium } = require('playwright');
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';
(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  page.on('response', async (resp) => {
    const u = resp.url();
    if (/\.js(\?|$)/.test(u)) {
      try {
        const body = await resp.text();
        if (/backend-api\/conversation|public-api\/conversation/.test(body)) {
          const name = u.split('/').pop().split('?')[0];
          require('fs').writeFileSync('/tmp/opencode/js/p_' + name, body);
          console.log('POSTBUNDLE', name, body.length);
        }
      } catch {}
    }
  });
  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  // try clicking composer to load the rest
  const sel = '#prompt-textarea, textarea';
  try { await page.click(sel, { timeout: 20000 }); } catch (e) { console.log('no textarea', e.message.split('\n')[0]); }
  await page.waitForTimeout(6000);
  await page.keyboard.type('hi', { delay: 10 });
  await page.waitForTimeout(2000);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(12000);
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
