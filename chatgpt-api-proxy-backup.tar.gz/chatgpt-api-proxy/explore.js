const { chromium } = require('playwright');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

async function api(page, path, opts = {}) {
  return page.evaluate(async ({ path, opts }) => {
    try {
      const r = await fetch(path, { credentials: 'include', ...opts });
      const body = await r.text();
      return { status: r.status, body: body.slice(0, 3000) };
    } catch (e) { return { err: String(e) }; }
  }, { path, opts });
}

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  try {
    await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
    for (let i = 0; i < 30; i++) {
      const html = await page.content();
      if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
      await page.waitForTimeout(2000);
    }
    console.log('TITLE:', await page.title());

    const models = await api(page, 'https://chatgpt.com/backend-api/models');
    console.log('=== MODELS status', models.status);
    try {
      const j = JSON.parse(models.body);
      console.log('count:', j.models.length);
      for (const m of j.models) console.log(' -', m.slug, '|', m.title, '| tags:', JSON.stringify(m.tags));
    } catch { console.log(models.body.slice(0, 800)); }

    const session = await api(page, 'https://chatgpt.com/api/auth/session');
    console.log('=== SESSION status', session.status, session.body.slice(0, 300));

    const conv = await api(page, 'https://chatgpt.com/backend-api/conversations?offset=0&limit=3');
    console.log('=== CONVERSATIONS status', conv.status, conv.body.slice(0, 300));
  } finally {
    await ctx.close();
  }
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
