const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  const saved = [];
  page.on('response', async (resp) => {
    const url = resp.url();
    if (/\.(?:js)(\?|$)/.test(url) && !saved.includes(url)) {
      saved.push(url);
      try {
        const body = await resp.body();
        const s = body.toString('utf8');
        if (s.includes('chat-requirements') || s.includes('backend-api/conversation"') || s.includes('/conversation"')) {
          const name = url.split('/').pop().split('?')[0];
          fs.writeFileSync('/tmp/opencode/js/' + name, body);
          console.log('SAVED', name, body.length);
        }
      } catch {}
    }
  });
  try {
    // plain homepage: main chat bundle loads here
    await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
    for (let i = 0; i < 30; i++) {
      const html = await page.content();
      if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
      await page.waitForTimeout(2000);
    }
    await page.waitForTimeout(10000);
    console.log('TITLE:', await page.title());
  } finally {
    await ctx.close();
  }
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
