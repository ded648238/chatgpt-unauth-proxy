const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);

  const sel = '#prompt-textarea, textarea';
  await page.waitForSelector(sel, { timeout: 30000 });
  // check composer attributes
  const info = await page.evaluate((s) => {
    const el = document.querySelector(s);
    if (!el) return null;
    return {
      tag: el.tagName, id: el.id,
      placeholder: el.placeholder,
      disabled: el.disabled,
      readOnly: el.readOnly,
      cls: el.className.slice(0, 200),
      parentHtml: el.parentElement.parentElement.parentElement.outerHTML.slice(0, 400),
    };
  }, sel);
  console.log('COMPOSER:', JSON.stringify(info, null, 1).slice(0, 1200));

  await page.click(sel);
  await page.waitForTimeout(800);
  await page.keyboard.type('Reply with exactly: PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(500);
  const typed = await page.evaluate((s) => document.querySelector(s).value, sel);
  console.log('TYPED VALUE:', JSON.stringify(typed));

  await page.keyboard.press('Enter');
  await page.waitForTimeout(4000);

  // what happened in DOM?
  const after = await page.evaluate(() => {
    const body = document.body.innerText;
    const msgs = [...document.querySelectorAll('[data-message-author-role], article, [class*="message"]')].map(e => e.outerHTML.slice(0, 200));
    return { url: location.href, title: document.title, bodySnippet: body.slice(0, 1500), msgCount: msgs.length, msgs: msgs.slice(0, 6) };
  });
  console.log('AFTER:', JSON.stringify(after, null, 1).slice(0, 3500));

  await page.screenshot({ path: '/tmp/opencode/after-send.png' });
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
