const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  const recs = [];
  page.on('request', (req) => {
    const u = req.url();
    if (/conversation\/updates|conversation\/prepare|chat-requirements|sentinel\/req/.test(u)) {
      recs.push({ kind: 'req', m: req.method(), u, headers: req.headers(), post: req.postData() });
    }
  });
  page.on('response', async (resp) => {
    const u = resp.url();
    if (/conversation\/updates|conversation\/prepare|chat-requirements|sentinel\/req/.test(u)) {
      try {
        const body = await resp.text();
        recs.push({ kind: 'resp', status: resp.status(), u, ct: resp.headers()['content-type'], body: body.slice(0, 4000) });
      } catch (e) {
        recs.push({ kind: 'resp-err', u, err: e.message });
      }
    }
  });

  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  const sel = '#mobile-composer-prompt, #prompt-textarea, textarea';
  await page.waitForSelector(sel, { timeout: 30000 });
  await page.click(sel);
  await page.waitForTimeout(800);
  await page.keyboard.type('Say: PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(600);
  await page.click('button[aria-label*="Send" i]').catch(() => page.keyboard.press('Enter'));
  await page.waitForTimeout(30000);

  fs.writeFileSync('/tmp/opencode/flow.json', JSON.stringify(recs, null, 2));
  console.log('records:', recs.length);
  for (const r of recs) {
    if (r.kind === 'req') console.log('REQ', r.m, r.u.slice(0, 110));
    else console.log('RESP', r.status, r.u.slice(0, 110), 'ct=', r.ct, 'len=', r.body ? r.body.length : 0);
  }
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
