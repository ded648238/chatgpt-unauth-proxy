const { chromium } = require('playwright');
const fs = require('fs');
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';
(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  const log = [];
  page.on('request', (req) => {
    const u = req.url();
    if (/chatgpt\.com\/(backend-api|public-api|unauth-mweb\/conversation)/.test(u) && !/\.js|\.svg|\.png/.test(u)) {
      const rec = { m: req.method(), url: u, headers: req.headers(), post: req.postData() };
      if (rec.post && rec.post.length > 2000) rec.post = rec.post.slice(0, 2000) + '...TRUNC';
      log.push(rec);
    }
  });
  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  const sel = '#prompt-textarea, textarea';
  await page.waitForSelector(sel, { timeout: 30000 });
  await page.click(sel);
  await page.waitForTimeout(2000);
  await page.keyboard.type('Reply with exactly PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(600);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(20000);
  fs.writeFileSync('/tmp/opencode/net.json', JSON.stringify(log, null, 2));
  console.log('captured', log.length);
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
