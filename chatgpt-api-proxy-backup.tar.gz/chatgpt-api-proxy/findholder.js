const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  const sel = '#mobile-composer-prompt, #prompt-textarea, textarea';
  await page.waitForSelector(sel, { timeout: 30000 });
  await page.click(sel);
  await page.waitForTimeout(800);
  await page.keyboard.type('Count from 1 to 5, one number per line.', { delay: 15 });
  await page.waitForTimeout(500);
  await page.click('button[aria-label*="Send" i]');
  await page.waitForTimeout(25000);

  // full body text
  const full = await page.evaluate(() => document.body.innerText);
  console.log('=== BODY TEXT ===');
  console.log(full.slice(0, 2000));
  console.log('=== URL', await page.evaluate(() => location.href));

  // find element containing "1\n2\n3"
  const holder = await page.evaluate(() => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    let node, best = null;
    while ((node = walker.nextNode())) {
      const t = (node.innerText || '').trim();
      if (/^1\s*\n\s*2/.test(t) && (!best || t.length < best.text.length)) {
        best = { tag: node.tagName, cls: String(node.className).slice(0, 150), text: t.slice(0, 200), attrs: [...node.attributes].map(a => a.name + '=' + a.value.slice(0, 60)).join(' ') };
      }
    }
    return best;
  });
  console.log('=== HOLDER ===', JSON.stringify(holder, null, 1));
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
