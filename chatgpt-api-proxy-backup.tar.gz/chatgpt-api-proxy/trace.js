const { chromium } = require('playwright');
const fs = require('fs');
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';
(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  const all = [];
  page.on('request', (req) => all.push({ m: req.method(), u: req.url(), post: (req.postData()||'').slice(0,300) }));
  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  await page.waitForSelector('#prompt-textarea, textarea', { timeout: 30000 });
  await page.click('#prompt-textarea, textarea');
  await page.waitForTimeout(1500);
  await page.keyboard.type('Reply with exactly: PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(500);
  const before = all.length;
  await page.keyboard.press('Enter');
  await page.waitForTimeout(25000);
  const after = all.slice(before);
  console.log('new requests after Enter:', after.length);
  for (const r of after) if (!/\.(js|svg|png|css|woff|json)/.test(r.u) || /conversation/.test(r.u)) console.log(r.m, r.u, r.post.slice(0,120));
  fs.writeFileSync('/tmp/opencode/after.json', JSON.stringify(after, null, 2));
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
