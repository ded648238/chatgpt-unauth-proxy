const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  const hit = [];
  page.on('request', (req) => {
    const u = req.url();
    if (u.includes('backend-api') || u.includes('public-api')) {
      hit.push({ method: req.method(), url: u, headers: req.headers(), post: req.postData() });
      console.log('REQ', req.method(), u);
    }
  });
  page.on('response', async (resp) => {
    const u = resp.url();
    if (u.includes('conversation') && !u.includes('conversations')) {
      try {
        const body = await resp.text();
        console.log('RESP', resp.status(), u, 'len', body.length, body.slice(0, 400).replace(/\n/g, '\n'));
      } catch {}
    }
  });

  try {
    await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
    for (let i = 0; i < 30; i++) {
      const html = await page.content();
      if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
      await page.waitForTimeout(2000);
    }
    await page.waitForTimeout(6000);
    console.log('TITLE:', await page.title());

    // find composer textarea
    const sel = '#prompt-textarea, textarea[data-id], textarea';
    await page.waitForSelector(sel, { timeout: 30000 });
    await page.click(sel);
    await page.keyboard.type('Say exactly: PROXY-TEST-OK. Nothing else.', { delay: 20 });
    await page.waitForTimeout(400);
    await page.keyboard.press('Enter');
    console.log('SENT, waiting for stream...');
    await page.waitForTimeout(15000);
    fs.writeFileSync('/tmp/opencode/traffic.json', JSON.stringify(hit, null, 2));
    console.log('total reqs:', hit.length);
  } finally {
    await ctx.close();
  }
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
