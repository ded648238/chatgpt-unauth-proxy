const { chromium } = require('playwright');
const fs = require('fs');
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';
(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  const client = await ctx.newCDPSession(page);
  const reqs = new Map();
  await client.send('Network.enable');
  client.on('Network.requestWillBeSent', (e) => {
    reqs.set(e.requestId, e.request);
    const u = e.request.url;
    if (/conversation|backend-api|public-api|socket|conduit|realtime|event/.test(u) && !/\.(js|svg|png|css|woff)/.test(u))
      console.log('REQ', e.request.method, u);
  });
  client.on('Network.webSocketCreated', (e) => console.log('WS', e.url));
  client.on('Network.responseReceived', (e) => {
    const u = e.response.url;
    if (/backend-api\/conversation|public-api\/conversation|\/conversation(\/|$|\?)/.test(u)) {
      console.log('RESP', e.response.status, u, e.response.mimeType);
    }
  });
  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);
  await page.waitForSelector('#prompt-textarea, textarea', { timeout: 30000 });
  await page.click('#prompt-textarea, textarea');
  await page.waitForTimeout(1500);
  await page.keyboard.type('Reply with exactly: PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(500);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(25000);
  // dump bodies of any conversation requests
  const dump = [];
  for (const [id, req] of reqs) {
    if (/backend-api\/conversation|public-api\/conversation|conduit/.test(req.url)) dump.push({ id, ...req });
  }
  fs.writeFileSync('/tmp/opencode/reqs.json', JSON.stringify(dump, null, 2));
  console.log('dumped', dump.length);
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
