const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  const captured = [];
  let swClient = null;

  ctx.on('serviceworker', async (worker) => {
    console.log('SW registered:', worker.url());
    try {
      swClient = await ctx.newCDPSession(worker);
      await swClient.send('Network.enable');
      swClient.on('Network.requestWillBeSent', (e) => {
        const u = e.request.url;
        if (/conversation|backend-api|public-api|conduit|realtime|event-stream|\/stream/.test(u) && !/\.(js|svg|png|css)/.test(u)) {
          console.log('SW REQ', e.request.method, u);
          captured.push({ src: 'sw', method: e.request.method, url: u, headers: e.request.headers, post: e.request.postData });
        }
      });
      swClient.on('Network.webSocketCreated', (e) => console.log('SW WS', e.url));
      swClient.on('Network.responseReceived', (e) => {
        const u = e.response.url;
        if (/backend-api\/conversation|public-api\/conversation|conduit/.test(u)) console.log('SW RESP', e.response.status, u);
      });
      await worker.evaluate(() => {
        self.__proxyLog = [];
        const origFetch = self.fetch;
        self.fetch = async function (...args) {
          const req = args[0];
          const url = typeof req === 'string' ? req : (req && req.url);
          const method = typeof req === 'string' ? 'GET' : (req && req.method) || 'GET';
          if (/conversation|backend-api|public-api|conduit/i.test(String(url))) {
            let body = null;
            if (req && req.body) { try { body = await new Response(req.body).text(); } catch {} }
            self.__proxyLog.push({ url: String(url), method, body: body ? body.slice(0, 3000) : null });
          }
          return origFetch.apply(this, args);
        };
        console.log('fetch hooked');
      }).catch(e => console.log('sw hook err', e.message.split('\n')[0]));
    } catch (e) {
      console.log('sw cdp err', e.message.split('\n')[0]);
    }
  });

  // page-level too
  const pclient = await ctx.newCDPSession(page);
  await pclient.send('Network.enable');
  pclient.on('Network.webSocketCreated', (e) => console.log('PAGE WS', e.url));

  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);

  // dump registered SWs via page
  const sws = await page.evaluate(async () => {
    const out = [];
    const reg = await navigator.serviceWorker.getRegistrations();
    for (const r of reg) out.push({ scope: r.scope, scriptURL: r.active && r.active.scriptURL, state: r.active && r.active.state });
    return out;
  }).catch(e => ({ err: e.message }));
  console.log('SWs:', JSON.stringify(sws, null, 1));

  await page.waitForSelector('#prompt-textarea, textarea', { timeout: 30000 });
  await page.click('#prompt-textarea, textarea');
  await page.waitForTimeout(1500);
  await page.keyboard.type('Reply with exactly: PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(500);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(25000);

  // pull hook log from SW
  const regs = await page.evaluate(() => navigator.serviceWorker.getRegistrations().then(r => r.map(x => x.scope)));
  console.log('regs now:', regs);

  fs.writeFileSync('/tmp/opencode/sw.json', JSON.stringify(captured, null, 2));
  console.log('captured', captured.length);
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
