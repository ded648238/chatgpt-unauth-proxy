const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({
    executablePath: '/usr/bin/google-chrome',
    args: ['--disable-blink-features=AutomationControlled', '--no-sandbox', '--disable-gpu'],
  });
  const page = await browser.newPage();
  const t0 = Date.now();
  try {
    await page.goto('https://chatgpt.com/', { timeout: 60000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(10000);
    const html = await page.content();
    console.log('elapsed', ((Date.now() - t0) / 1000).toFixed(1) + 's len=' + html.length);
    console.log('cf_challenge:', html.includes('_cf_chl_opt'));
    console.log('title:', await page.title());
    console.log('cookies:', (await page.context().cookies()).map(c => c.name).join(','));

    const res = await page.evaluate(async () => {
      try {
        const r = await fetch('https://chatgpt.com/backend-api/models', { credentials: 'include' });
        return { status: r.status, body: (await r.text()).slice(0, 400) };
      } catch (e) { return { err: String(e) }; }
    });
    console.log('models:', JSON.stringify(res).slice(0, 500));
  } finally {
    await browser.close();
  }
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
