const { chromium } = require('playwright');
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';
(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();
  page.on('response', async (resp) => {
    const u = resp.url();
    if (u.endsWith('.js') || /\.js\?/.test(u)) {
      try {
        const body = await resp.text();
        if (/conduit/.test(body)) {
          const name = u.split('/').pop().split('?')[0];
          require('fs').writeFileSync('/tmp/opencode/js/c_' + name, body);
          console.log('CONDUIT', name, body.length);
        }
      } catch {}
    }
  });
  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(10000);
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
