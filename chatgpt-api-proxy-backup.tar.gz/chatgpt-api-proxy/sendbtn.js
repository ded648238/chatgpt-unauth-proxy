const { chromium } = require('playwright');
const fs = require('fs');

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36';

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  const log = [];
  page.on('request', (req) => {
    const u = req.url();
    if (/backend-api|public-api|conversation|conduit|realtime/.test(u) && !/\.(js|svg|png|css|woff)/.test(u)) {
      log.push({ m: req.method(), u, post: (req.postData() || '').slice(0, 800) });
    }
  });

  await page.goto('https://chatgpt.com/', { timeout: 90000, waitUntil: 'domcontentloaded' });
  for (let i = 0; i < 30; i++) {
    const html = await page.content();
    if (!html.includes('_cf_chl_opt') && !html.includes('Just a moment')) break;
    await page.waitForTimeout(2000);
  }
  await page.waitForTimeout(4000);

  const sel = '#mobile-composer-prompt, #prompt-textarea, textarea';
  await page.waitForSelector(sel, { timeout: 30000 });
  await page.click(sel);
  await page.waitForTimeout(800);
  await page.keyboard.type('Reply with exactly: PROXY-TEST-OK', { delay: 15 });
  await page.waitForTimeout(600);

  // enumerate buttons near composer
  const btns = await page.evaluate(() => {
    const els = [...document.querySelectorAll('button')];
    return els.filter(b => !/Accept|Reject|cookie|Log in|Sign|Help|Settings|New chat|See plans/i.test(b.innerText || b.getAttribute('aria-label') || ''))
      .map(b => ({
        text: (b.innerText || '').trim().slice(0, 40),
        aria: b.getAttribute('aria-label'),
        disabled: b.disabled,
        cls: (b.className || '').slice(0, 80),
        rect: (() => { const r = b.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; })(),
      }));
  });
  console.log('BUTTONS:', JSON.stringify(btns, null, 1).slice(0, 2500));

  // click send via aria-label guesses
  const sendSel = ['button[aria-label*="Send" i]', 'button[aria-label*="submit" i]', 'button[data-testid="send-button"]'];
  let clicked = false;
  for (const s of sendSel) {
    try {
      const el = await page.$(s);
      if (el) {
        const dis = await el.evaluate(b => b.disabled);
        console.log('found', s, 'disabled=', dis);
        if (!dis) { await el.click(); clicked = true; console.log('CLICKED', s); break; }
      }
    } catch {}
  }
  if (!clicked) console.log('no send button found via aria');
  await page.waitForTimeout(25000);

  const after = await page.evaluate(() => ({
    url: location.href,
    body: document.body.innerText.slice(0, 1200),
  }));
  console.log('AFTER:', JSON.stringify(after, null, 1).slice(0, 2000));
  console.log('LOG:', JSON.stringify(log.filter(r => !/sentinel|events\//.test(r.u)), null, 1).slice(0, 3000));
  await ctx.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
