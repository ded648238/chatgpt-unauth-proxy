const { chromium } = require('playwright');
const { ChatGPTDriver } = require('./driver');

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
  const d = new ChatGPTDriver();
  await d.attach(browser);
  await d.warmup();
  console.log('warm ok');

  const t0 = Date.now();
  const r1 = await d.ask('My name is Alexander. Remember it.', (dl) => process.stdout.write('[' + dl + ']'));
  console.log('\nR1:', JSON.stringify(r1.slice(0, 120)), ((Date.now() - t0) / 1000).toFixed(1) + 's');

  const t1 = Date.now();
  const r2 = await d.ask('What is my name? Answer with one word.', (dl) => process.stdout.write('[' + dl + ']'));
  console.log('\nR2:', JSON.stringify(r2.slice(0, 120)), ((Date.now() - t1) / 1000).toFixed(1) + 's');

  await d.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
